<?php

/**
 * MÉTHODE À AJOUTER DANS app/Services/PdgService.php
 * 
 * Cette méthode récupère le flux opérationnel complet incluant:
 * - Réceptions du jour
 * - Stock initial
 * - Ventes
 * - Retours
 * - Stock final
 * - Calculs de performance
 */

use App\Models\SessionVente;
use App\Models\ReceptionPointeur;
use App\Models\RetourProduit;
use App\Models\InventaireDetail;

public function getFluxOperationnel($date, $vendeurId = null, $produitId = null)
{
    try {
        // Récupérer les sessions de vente du jour
        $query = SessionVente::with(['vendeur', 'ventes.produit'])
            ->whereDate('date_ouverture', $date);
        
        if ($vendeurId) {
            $query->where('vendeur_id', $vendeurId);
        }
        
        $sessions = $query->get();
        $flux = [];
        $totalReceptions = 0;
        $totalVentesValue = 0;
        $totalProduitsVendus = 0;
        
        foreach ($sessions as $session) {
            $produitsFlux = [];
            
            // Grouper les ventes par produit
            $ventesProduits = $session->ventes->groupBy('produit_id');
            
            foreach ($ventesProduits as $produitId_item => $ventes) {
                // Filtrer par produit si spécifié
                if ($produitId && $produitId_item != $produitId) {
                    continue;
                }
                
                $produit = $ventes->first()->produit;
                $quantiteVendue = $ventes->sum('quantite');
                $valeurVente = $ventes->sum('montant_total');
                
                // Récupérer les réceptions du jour pour ce produit et ce vendeur
                $receptionsQuantite = ReceptionPointeur::where('produit_id', $produitId_item)
                    ->where('vendeur_assigne_id', $session->vendeur_id)
                    ->whereDate('date_reception', $date)
                    ->sum('quantite');
                
                $totalReceptions += $receptionsQuantite;
                
                // Stock initial (inventaire du jour précédent ou dernier inventaire)
                $datePrecedente = \Carbon\Carbon::parse($date)->subDay();
                
                $inventairePrecedent = InventaireDetail::whereHas('inventaire', function($q) use ($datePrecedente, $session, $produit) {
                        $q->where('vendeur_entrant_id', $session->vendeur_id)
                          ->whereDate('date_inventaire', '<=', $datePrecedente)
                          ->where('categorie', $produit->categorie)
                          ->where('valide_entrant', true);
                    })
                    ->where('produit_id', $produitId_item)
                    ->orderBy('created_at', 'desc')
                    ->first();
                
                $stockInitial = $inventairePrecedent ? $inventairePrecedent->quantite_restante : 0;
                
                // Retours du jour
                $retoursQuantite = RetourProduit::where('produit_id', $produitId_item)
                    ->where('vendeur_id', $session->vendeur_id)
                    ->whereDate('date_retour', $date)
                    ->sum('quantite');
                
                // Stock final (inventaire du jour si disponible)
                $inventaireJour = InventaireDetail::whereHas('inventaire', function($q) use ($date, $session, $produit) {
                        $q->where('vendeur_sortant_id', $session->vendeur_id)
                          ->whereDate('date_inventaire', $date)
                          ->where('categorie', $produit->categorie);
                    })
                    ->where('produit_id', $produitId_item)
                    ->first();
                
                // Si pas d'inventaire du jour, calculer: stock_initial + réceptions - vendus - retours
                $stockFinal = $inventaireJour 
                    ? $inventaireJour->quantite_restante 
                    : ($stockInitial + $receptionsQuantite - $quantiteVendue - $retoursQuantite);
                
                // Calcul du total disponible
                $totalDisponible = $stockInitial + $receptionsQuantite;
                
                // Calcul du taux de vente
                $tauxVente = $totalDisponible > 0 
                    ? round(($quantiteVendue / $totalDisponible) * 100, 2) 
                    : 0;
                
                $produitsFlux[] = [
                    'produit_id' => $produitId_item,
                    'produit_nom' => $produit->nom,
                    'produit' => $produit->nom, // Alias pour compatibilité
                    'prix_unitaire' => $produit->prix,
                    'categorie' => $produit->categorie,
                    
                    // Flux du jour
                    'reception' => $receptionsQuantite,
                    'quantite_recue' => $receptionsQuantite, // Alias
                    'stock_initial' => $stockInitial,
                    'quantite_trouvee' => $stockInitial, // Alias
                    'quantite_vendue' => $quantiteVendue,
                    'retours' => $retoursQuantite,
                    'quantite_retour' => $retoursQuantite, // Alias
                    'stock_final' => $stockFinal,
                    'quantite_restante' => $stockFinal, // Alias
                    
                    // Valeurs financières
                    'valeur_vente' => $valeurVente,
                    'valeur_reception' => $receptionsQuantite * $produit->prix,
                    'valeur_stock_initial' => $stockInitial * $produit->prix,
                    'valeur_stock_final' => $stockFinal * $produit->prix,
                    
                    // Indicateurs
                    'total_disponible' => $totalDisponible,
                    'taux_vente' => $tauxVente,
                    'performance' => $tauxVente >= 80 ? 'good' : ($tauxVente >= 50 ? 'warning' : 'danger'),
                    
                    // Détails des ventes (pour affichage détaillé si nécessaire)
                    'details' => $ventes->map(function($vente) {
                        return [
                            'heure' => $vente->date_vente->format('H:i'),
                            'quantite' => $vente->quantite,
                            'montant' => $vente->montant_total,
                            'mode_paiement' => $vente->mode_paiement,
                        ];
                    })->toArray(),
                ];
                
                $totalProduitsVendus += $quantiteVendue;
                $totalVentesValue += $valeurVente;
            }
            
            // Ajouter le flux du vendeur
            if (!empty($produitsFlux)) {
                $flux[] = [
                    'vendeur' => [
                        'id' => $session->vendeur_id,
                        'nom' => $session->vendeur->name,
                        'role' => $session->vendeur->role,
                        'categorie' => $session->categorie,
                    ],
                    'session' => [
                        'id' => $session->id,
                        'date_ouverture' => $session->date_ouverture,
                        'statut' => $session->statut,
                        'fond_vente' => $session->fond_vente,
                    ],
                    'produits' => $produitsFlux,
                    'total_ventes' => collect($produitsFlux)->sum('valeur_vente'),
                    'total_quantites' => collect($produitsFlux)->sum('quantite_vendue'),
                    'total_receptions' => collect($produitsFlux)->sum('reception'),
                ];
            }
        }
        
        // Calculer le résumé global
        $resume = [
            'date' => $date,
            'nombre_vendeurs' => count($flux),
            'total_ventes' => $totalVentesValue,
            'total_produits' => $totalProduitsVendus,
            'total_receptions' => $totalReceptions,
            'chiffre_affaire' => $totalVentesValue,
            
            // Statistiques additionnelles
            'produits_uniques' => $sessions->flatMap(function($session) {
                return $session->ventes->pluck('produit_id');
            })->unique()->count(),
            
            'moyenne_par_vendeur' => count($flux) > 0 ? round($totalVentesValue / count($flux), 2) : 0,
        ];
        
        return [
            'date' => $date,
            'flux' => $flux,
            'resume' => $resume,
            'filters' => [
                'vendeur_id' => $vendeurId,
                'produit_id' => $produitId,
            ],
        ];
        
    } catch (\Exception $e) {
        \Log::error('Erreur getFluxOperationnel', [
            'date' => $date,
            'vendeur_id' => $vendeurId,
            'produit_id' => $produitId,
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
        ]);
        
        return [
            'date' => $date,
            'flux' => [],
            'resume' => [
                'total_ventes' => 0,
                'total_produits' => 0,
                'total_receptions' => 0,
                'chiffre_affaire' => 0,
            ],
            'error' => $e->getMessage(),
        ];
    }
}

/**
 * MÉTHODES AUXILIAIRES (optionnelles mais recommandées)
 */

/**
 * Obtenir le dernier inventaire validé pour un vendeur et une catégorie
 */
private function getDernierInventaireValide($vendeurId, $categorie, $date)
{
    return \App\Models\Inventaire::where('vendeur_entrant_id', $vendeurId)
        ->where('categorie', $categorie)
        ->where('valide_entrant', true)
        ->whereDate('date_inventaire', '<=', $date)
        ->orderBy('date_inventaire', 'desc')
        ->first();
}

/**
 * Calculer les métriques de performance d'un produit
 */
private function calculerPerformanceProduit($quantiteVendue, $totalDisponible)
{
    if ($totalDisponible <= 0) {
        return [
            'taux' => 0,
            'niveau' => 'no_data',
            'couleur' => 'gray',
        ];
    }
    
    $taux = round(($quantiteVendue / $totalDisponible) * 100, 2);
    
    if ($taux >= 80) {
        return ['taux' => $taux, 'niveau' => 'excellent', 'couleur' => 'green'];
    } elseif ($taux >= 60) {
        return ['taux' => $taux, 'niveau' => 'bon', 'couleur' => 'blue'];
    } elseif ($taux >= 40) {
        return ['taux' => $taux, 'niveau' => 'moyen', 'couleur' => 'yellow'];
    } else {
        return ['taux' => $taux, 'niveau' => 'faible', 'couleur' => 'red'];
    }
}
