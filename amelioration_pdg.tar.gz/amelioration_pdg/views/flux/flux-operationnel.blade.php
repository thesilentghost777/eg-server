@extends('layouts.app')

@section('title', $isFrench ? 'Flux Opérationnel' : 'Operational Flow')

@section('styles')
<style>
    .bread-gradient {
        background: linear-gradient(135deg, #D4A574 0%, #C89968 50%, #B08554 100%);
    }
    
    @media print {
        .no-print { display: none !important; }
        .print-full-width { width: 100% !important; }
        body { font-size: 10pt; }
    }
    
    /* Optimisation pour grands volumes - Vue compacte */
    .compact-view .produit-card {
        padding: 0.75rem !important;
        margin-bottom: 0.5rem !important;
    }
    
    .compact-view .metric {
        font-size: 0.875rem !important;
        padding: 0.5rem !important;
    }
    
    /* Vue tableau pour grands volumes */
    .table-view {
        max-height: 600px;
        overflow-y: auto;
    }
    
    .sticky-header {
        position: sticky;
        top: 0;
        z-index: 10;
        background: linear-gradient(135deg, #D4A574 0%, #C89968 50%, #B08554 100%);
    }
    
    /* Mise en surbrillance des valeurs importantes */
    .highlight-value {
        background-color: #fef3c7;
        font-weight: bold;
    }
    
    /* Indicateur de performance */
    .perf-good { color: #10b981; }
    .perf-warning { color: #f59e0b; }
    .perf-danger { color: #ef4444; }
</style>
@endsection

@section('content')
<div class="min-h-screen bg-gradient-to-br from-amber-50 via-white to-blue-50">
    <div class="container mx-auto px-4 py-6 sm:py-8">
        <!-- Header -->
        <div class="bg-gradient-to-r from-amber-700 to-amber-600 rounded-2xl shadow-xl p-6 sm:p-8 mb-6 no-print">
            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h1 class="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-2">
                        <i class="fas fa-stream mr-3"></i>
                        {{ $isFrench ? 'Flux Opérationnel' : 'Operational Flow' }}
                    </h1>
                    <p class="text-amber-50 text-sm sm:text-base">
                        {{ $isFrench ? 'Suivi des opérations -' : 'Operations tracking -' }} {{ $selectedDate ?? '' }}
                    </p>
                </div>
                <div class="flex gap-2">
                    <button onclick="toggleView()" class="px-4 py-2 bg-white text-amber-700 rounded-lg hover:bg-amber-50 transition-all">
                        <i class="fas fa-th-list mr-2"></i>
                        <span id="viewToggleText">{{ $isFrench ? 'Vue Tableau' : 'Table View' }}</span>
                    </button>
                    <a href="{{ route('pdg.flux.imprimer', request()->all()) }}" target="_blank"
                       class="px-4 py-2 bg-white text-amber-700 rounded-lg hover:bg-amber-50 transition-all shadow-md">
                        <i class="fas fa-print mr-2"></i>{{ $isFrench ? 'Imprimer' : 'Print' }}
                    </a>
                </div>
            </div>
        </div>

        <!-- Filtres -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6 no-print">
            <form method="GET" action="{{ route('pdg.flux') }}" class="space-y-4">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <!-- Date -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-calendar mr-1 text-amber-600"></i>
                            {{ $isFrench ? 'Date' : 'Date' }}
                        </label>
                        <input type="date" name="date" value="{{ $selectedDate }}" required
                               class="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-amber-500">
                    </div>

                    <!-- Vendeur -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-user mr-1 text-blue-600"></i>
                            {{ $isFrench ? 'Vendeur' : 'Seller' }}
                        </label>
                        <select name="vendeur_id" class="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500">
                            <option value="">{{ $isFrench ? 'Tous les vendeurs' : 'All sellers' }}</option>
                            @foreach($vendeurs ?? [] as $vendeur)
                                <option value="{{ $vendeur->id }}" {{ $selectedVendeur == $vendeur->id ? 'selected' : '' }}>
                                    {{ $vendeur->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Produit -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-box mr-1 text-green-600"></i>
                            {{ $isFrench ? 'Produit' : 'Product' }}
                        </label>
                        <select name="produit_id" class="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-green-500">
                            <option value="">{{ $isFrench ? 'Tous les produits' : 'All products' }}</option>
                            @foreach($produits ?? [] as $produit)
                                <option value="{{ $produit->id }}" {{ $selectedProduit == $produit->id ? 'selected' : '' }}>
                                    {{ $produit->nom }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Raccourcis -->
                    <div class="flex items-end space-x-2">
                        <button type="button" onclick="setToday()" 
                                class="flex-1 px-3 py-2 bg-blue-500 text-white text-sm rounded-lg hover:bg-blue-600">
                            <i class="fas fa-calendar-day mr-1"></i>
                            {{ $isFrench ? 'Aujourd\'hui' : 'Today' }}
                        </button>
                        <button type="button" onclick="setYesterday()" 
                                class="flex-1 px-3 py-2 bg-gray-500 text-white text-sm rounded-lg hover:bg-gray-600">
                            <i class="fas fa-calendar-minus mr-1"></i>
                            {{ $isFrench ? 'Hier' : 'Yesterday' }}
                        </button>
                    </div>
                </div>

                <div class="flex gap-3">
                    <button type="submit" class="px-6 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 shadow-md">
                        <i class="fas fa-search mr-2"></i>{{ $isFrench ? 'Rechercher' : 'Search' }}
                    </button>
                    <a href="{{ route('pdg.flux') }}" class="px-6 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 shadow-md">
                        <i class="fas fa-redo mr-2"></i>{{ $isFrench ? 'Réinitialiser' : 'Reset' }}
                    </a>
                </div>
            </form>
        </div>

        <!-- Résumé Global -->
        @if(isset($flux['resume']))
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
                <div class="flex items-center justify-between mb-2">
                    <i class="fas fa-users text-3xl text-green-500"></i>
                    <span class="text-3xl font-bold text-gray-800">{{ count($flux['flux'] ?? []) }}</span>
                </div>
                <h3 class="text-sm font-semibold text-gray-600">{{ $isFrench ? 'Vendeurs Actifs' : 'Active Sellers' }}</h3>
            </div>

            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
                <div class="flex items-center justify-between mb-2">
                    <i class="fas fa-shopping-cart text-3xl text-blue-500"></i>
                    <span class="text-2xl font-bold text-gray-800">{{ number_format($flux['resume']['total_ventes'] ?? 0, 0, ',', ' ') }}</span>
                </div>
                <h3 class="text-sm font-semibold text-gray-600">{{ $isFrench ? 'Valeur Totale (FCFA)' : 'Total Value (FCFA)' }}</h3>
            </div>

            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
                <div class="flex items-center justify-between mb-2">
                    <i class="fas fa-boxes text-3xl text-purple-500"></i>
                    <span class="text-3xl font-bold text-gray-800">{{ $flux['resume']['total_produits'] ?? 0 }}</span>
                </div>
                <h3 class="text-sm font-semibold text-gray-600">{{ $isFrench ? 'Produits Vendus' : 'Products Sold' }}</h3>
            </div>

            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-orange-500">
                <div class="flex items-center justify-between mb-2">
                    <i class="fas fa-truck text-3xl text-orange-500"></i>
                    <span class="text-3xl font-bold text-gray-800">{{ $flux['resume']['total_receptions'] ?? 0 }}</span>
                </div>
                <h3 class="text-sm font-semibold text-gray-600">{{ $isFrench ? 'Réceptions Jour' : 'Daily Receptions' }}</h3>
            </div>
        </div>
        @endif

        <!-- Vue Cartes (par défaut) -->
        <div id="cardView" class="space-y-6">
            @forelse($flux['flux'] ?? [] as $fluxVendeur)
            <div class="bg-white rounded-xl shadow-lg p-6">
                <!-- En-tête Vendeur -->
                <div class="flex items-center justify-between mb-6 pb-4 border-b-2 border-amber-200">
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 rounded-full bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center">
                            <i class="fas fa-user text-white text-xl"></i>
                        </div>
                        <div>
                            <h2 class="text-xl font-bold text-gray-800">{{ $fluxVendeur['vendeur']['nom'] }}</h2>
                            <p class="text-sm text-gray-500">{{ ucfirst(str_replace('_', ' ', $fluxVendeur['vendeur']['role'])) }}</p>
                        </div>
                    </div>
                    <div class="text-right">
                        <p class="text-sm text-gray-500">{{ $isFrench ? 'Valeur Totale' : 'Total Value' }}</p>
                        <p class="text-2xl font-bold text-amber-600">{{ number_format($fluxVendeur['total_ventes'] ?? 0, 0, ',', ' ') }} FCFA</p>
                    </div>
                </div>

                <!-- Produits -->
                <div class="space-y-3">
                    @forelse($fluxVendeur['produits'] ?? [] as $produitFlux)
                    <div class="produit-card bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h4 class="font-bold text-gray-800 text-lg">{{ $produitFlux['produit_nom'] ?? $produitFlux['produit'] ?? 'Produit' }}</h4>
                                <p class="text-sm text-gray-600">Prix unitaire: {{ $produitFlux['prix_unitaire'] ?? 0 }} FCFA</p>
                            </div>
                            <span class="px-4 py-2 bg-green-100 text-green-800 rounded-full text-sm font-bold">
                                {{ $produitFlux['quantite_vendue'] ?? 0 }} {{ $isFrench ? 'vendus' : 'sold' }}
                            </span>
                        </div>
                        
                        <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
                            <!-- Réception du jour -->
                            <div class="metric bg-blue-50 p-3 rounded-lg">
                                <p class="text-xs text-gray-600 mb-1">
                                    <i class="fas fa-truck text-blue-600 mr-1"></i>
                                    {{ $isFrench ? 'Réception' : 'Reception' }}
                                </p>
                                <p class="text-xl font-bold text-blue-600">{{ $produitFlux['reception'] ?? $produitFlux['quantite_recue'] ?? 0 }}</p>
                            </div>

                            <!-- Stock Initial -->
                            <div class="metric bg-purple-50 p-3 rounded-lg">
                                <p class="text-xs text-gray-600 mb-1">
                                    <i class="fas fa-box-open text-purple-600 mr-1"></i>
                                    {{ $isFrench ? 'Stock Initial' : 'Initial Stock' }}
                                </p>
                                <p class="text-xl font-bold text-purple-600">{{ $produitFlux['stock_initial'] ?? $produitFlux['quantite_trouvee'] ?? 0 }}</p>
                            </div>

                            <!-- Vendus -->
                            <div class="metric bg-green-50 p-3 rounded-lg">
                                <p class="text-xs text-gray-600 mb-1">
                                    <i class="fas fa-shopping-cart text-green-600 mr-1"></i>
                                    {{ $isFrench ? 'Vendus' : 'Sold' }}
                                </p>
                                <p class="text-xl font-bold text-green-600">{{ $produitFlux['quantite_vendue'] ?? 0 }}</p>
                            </div>

                            <!-- Retours -->
                            <div class="metric bg-orange-50 p-3 rounded-lg">
                                <p class="text-xs text-gray-600 mb-1">
                                    <i class="fas fa-undo text-orange-600 mr-1"></i>
                                    {{ $isFrench ? 'Retours' : 'Returns' }}
                                </p>
                                <p class="text-xl font-bold text-orange-600">{{ $produitFlux['retours'] ?? $produitFlux['quantite_retour'] ?? 0 }}</p>
                            </div>

                            <!-- Stock Final -->
                            <div class="metric bg-gray-100 p-3 rounded-lg">
                                <p class="text-xs text-gray-600 mb-1">
                                    <i class="fas fa-boxes text-gray-600 mr-1"></i>
                                    {{ $isFrench ? 'Stock Final' : 'Final Stock' }}
                                </p>
                                <p class="text-xl font-bold text-gray-700">{{ $produitFlux['stock_final'] ?? $produitFlux['quantite_restante'] ?? 0 }}</p>
                            </div>
                        </div>

                        <!-- Valeur de vente -->
                        @if(isset($produitFlux['valeur_vente']) && $produitFlux['valeur_vente'] > 0)
                        <div class="mt-3 pt-3 border-t border-gray-200">
                            <div class="flex justify-between items-center">
                                <span class="text-sm font-medium text-gray-600">{{ $isFrench ? 'Valeur vendue:' : 'Value sold:' }}</span>
                                <span class="text-lg font-bold text-green-600">{{ number_format($produitFlux['valeur_vente'], 0, ',', ' ') }} FCFA</span>
                            </div>
                            
                            <!-- Taux de vente -->
                            @php
                                $total_disponible = ($produitFlux['reception'] ?? 0) + ($produitFlux['stock_initial'] ?? 0);
                                $taux_vente = $total_disponible > 0 ? (($produitFlux['quantite_vendue'] ?? 0) / $total_disponible) * 100 : 0;
                            @endphp
                            <div class="mt-2">
                                <div class="flex justify-between items-center mb-1">
                                    <span class="text-xs text-gray-600">{{ $isFrench ? 'Taux de vente' : 'Sales rate' }}</span>
                                    <span class="text-xs font-bold {{ $taux_vente >= 80 ? 'perf-good' : ($taux_vente >= 50 ? 'perf-warning' : 'perf-danger') }}">
                                        {{ number_format($taux_vente, 1) }}%
                                    </span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-2">
                                    <div class="h-2 rounded-full transition-all {{ $taux_vente >= 80 ? 'bg-green-500' : ($taux_vente >= 50 ? 'bg-yellow-500' : 'bg-red-500') }}"
                                         style="width: {{ min($taux_vente, 100) }}%"></div>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                    @empty
                    <p class="text-center text-gray-500 py-4">{{ $isFrench ? 'Aucun produit' : 'No products' }}</p>
                    @endforelse
                </div>
            </div>
            @empty
            <div class="bg-white rounded-xl shadow-lg p-12 text-center">
                <i class="fas fa-inbox text-6xl text-gray-300 mb-4"></i>
                <p class="text-xl text-gray-500">{{ $isFrench ? 'Aucune activité pour cette période' : 'No activity for this period' }}</p>
            </div>
            @endforelse
        </div>

        <!-- Vue Tableau (cachée par défaut) -->
        <div id="tableView" class="hidden bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="table-view">
                <table class="w-full text-sm">
                    <thead class="sticky-header text-white">
                        <tr>
                            <th class="px-3 py-2 text-left">{{ $isFrench ? 'Vendeur' : 'Seller' }}</th>
                            <th class="px-3 py-2 text-left">{{ $isFrench ? 'Produit' : 'Product' }}</th>
                            <th class="px-3 py-2 text-center">{{ $isFrench ? 'Réception' : 'Reception' }}</th>
                            <th class="px-3 py-2 text-center">{{ $isFrench ? 'Stock Ini.' : 'Init. Stock' }}</th>
                            <th class="px-3 py-2 text-center">{{ $isFrench ? 'Vendus' : 'Sold' }}</th>
                            <th class="px-3 py-2 text-center">{{ $isFrench ? 'Retours' : 'Returns' }}</th>
                            <th class="px-3 py-2 text-center">{{ $isFrench ? 'Stock Fin.' : 'Final Stock' }}</th>
                            <th class="px-3 py-2 text-right">{{ $isFrench ? 'Valeur' : 'Value' }}</th>
                            <th class="px-3 py-2 text-center">{{ $isFrench ? 'Taux' : 'Rate' }}</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @foreach($flux['flux'] ?? [] as $fluxVendeur)
                            @foreach($fluxVendeur['produits'] ?? [] as $produitFlux)
                            @php
                                $total_dispo = ($produitFlux['reception'] ?? 0) + ($produitFlux['stock_initial'] ?? 0);
                                $taux = $total_dispo > 0 ? (($produitFlux['quantite_vendue'] ?? 0) / $total_dispo) * 100 : 0;
                            @endphp
                            <tr class="hover:bg-amber-50">
                                <td class="px-3 py-2">{{ $fluxVendeur['vendeur']['nom'] }}</td>
                                <td class="px-3 py-2 font-semibold">{{ $produitFlux['produit_nom'] ?? $produitFlux['produit'] ?? '' }}</td>
                                <td class="px-3 py-2 text-center font-bold text-blue-600">{{ $produitFlux['reception'] ?? $produitFlux['quantite_recue'] ?? 0 }}</td>
                                <td class="px-3 py-2 text-center">{{ $produitFlux['stock_initial'] ?? $produitFlux['quantite_trouvee'] ?? 0 }}</td>
                                <td class="px-3 py-2 text-center font-bold text-green-600">{{ $produitFlux['quantite_vendue'] ?? 0 }}</td>
                                <td class="px-3 py-2 text-center text-orange-600">{{ $produitFlux['retours'] ?? $produitFlux['quantite_retour'] ?? 0 }}</td>
                                <td class="px-3 py-2 text-center">{{ $produitFlux['stock_final'] ?? $produitFlux['quantite_restante'] ?? 0 }}</td>
                                <td class="px-3 py-2 text-right font-bold">{{ number_format($produitFlux['valeur_vente'] ?? 0, 0, ',', ' ') }}</td>
                                <td class="px-3 py-2 text-center">
                                    <span class="px-2 py-1 rounded text-xs font-bold {{ $taux >= 80 ? 'bg-green-100 text-green-800' : ($taux >= 50 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800') }}">
                                        {{ number_format($taux, 0) }}%
                                    </span>
                                </td>
                            </tr>
                            @endforeach
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
let isTableView = false;

function toggleView() {
    const cardView = document.getElementById('cardView');
    const tableView = document.getElementById('tableView');
    const viewToggleText = document.getElementById('viewToggleText');
    
    isTableView = !isTableView;
    
    if (isTableView) {
        cardView.classList.add('hidden');
        tableView.classList.remove('hidden');
        viewToggleText.textContent = '{{ $isFrench ? "Vue Cartes" : "Card View" }}';
    } else {
        cardView.classList.remove('hidden');
        tableView.classList.add('hidden');
        viewToggleText.textContent = '{{ $isFrench ? "Vue Tableau" : "Table View" }}';
    }
}

function setToday() {
    document.querySelector('input[name="date"]').value = new Date().toISOString().split('T')[0];
}

function setYesterday() {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    document.querySelector('input[name="date"]').value = yesterday.toISOString().split('T')[0];
}
</script>
@endsection
