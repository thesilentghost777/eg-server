# ⚡ DÉMARRAGE RAPIDE - 5 MINUTES

## 🎯 Installation Express

### Étape 1: Sauvegarde (30 secondes)
```bash
cd /chemin/vers/votre/projet
cp app/Http/Controllers/Web/PdgController.php app/Http/Controllers/Web/PdgController.php.backup
cp routes/web.php routes/web.php.backup
```

### Étape 2: Copie des Fichiers (2 minutes)
```bash
# Routes
cp amelioration_pdg/routes/web_updated.php routes/web.php

# Contrôleur
cp amelioration_pdg/controllers/PdgController_updated.php app/Http/Controllers/Web/PdgController.php

# Vues Réceptions
cp amelioration_pdg/views/receptions/*.blade.php resources/views/pdg/

# Vues Inventaires (créer si nécessaire)
mkdir -p resources/views/pdg
cp amelioration_pdg/views/inventaires/*.blade.php resources/views/pdg/

# Vues Flux
cp amelioration_pdg/views/flux/*.blade.php resources/views/pdg/
```

### Étape 3: Mise à Jour du Service (1 minute)

Ouvrir `app/Services/PdgService.php` et ajouter à la fin de la classe:

```php
public function getFluxOperationnel($date, $vendeurId = null, $produitId = null)
{
    // Voir GUIDE_IMPLEMENTATION.md section "Mise à jour du Service PDG"
    // Copier la méthode complète depuis le guide
}
```

### Étape 4: Nettoyage Cache (30 secondes)
```bash
php artisan cache:clear
php artisan view:clear
php artisan route:clear
php artisan config:clear
```

### Étape 5: Test (1 minute)
```bash
# Lancer le serveur
php artisan serve

# Ouvrir le navigateur
# http://localhost:8000/pdg/receptions
```

---

## ✅ Vérification Rapide

### Test 1: Réceptions
```
1. Aller sur /pdg/receptions
2. Voir la liste des réceptions
3. Cliquer "Modifier" sur une réception non verrouillée
4. Changer la quantité
5. Enregistrer
✅ Si ça fonctionne → Installation OK!
```

### Test 2: Flux Opérationnel
```
1. Aller sur /pdg/flux-operationnel
2. Sélectionner une date
3. Cliquer "Rechercher"
4. Voir les données avec colonne "Réception"
5. Cliquer "Vue Tableau"
✅ Si ça bascule → Installation OK!
```

### Test 3: Impression
```
1. Sur n'importe quelle page
2. Cliquer "Imprimer"
3. Nouvelle fenêtre s'ouvre
4. Page formatée pour impression
✅ Si c'est bien formaté → Installation OK!
```

---

## 🚨 En Cas de Problème

### Erreur 404 sur les routes
```bash
php artisan route:list | grep pdg
php artisan route:cache
```

### Vue ne s'affiche pas
```bash
php artisan view:clear
chmod -R 775 storage/
chmod -R 775 bootstrap/cache/
```

### Erreur "Class not found"
```bash
composer dump-autoload
php artisan config:cache
```

---

## 📞 Support Rapide

**Logs Laravel:**
```bash
tail -f storage/logs/laravel.log
```

**Console Navigateur:**
```
Appuyez sur F12 → Onglet Console
```

---

## 🎉 C'est Tout!

Votre système est maintenant prêt à gérer:
- ✅ Modification des réceptions
- ✅ Modification des inventaires
- ✅ Flux avec colonne réceptions
- ✅ Filtres avancés
- ✅ Vue compacte pour 113+ produits
- ✅ Impressions optimisées
- ✅ Export CSV

**Temps total: ~5 minutes**

---

Pour plus de détails, consultez:
- 📘 [README.md](README.md) - Documentation complète
- 📗 [GUIDE_IMPLEMENTATION.md](docs/GUIDE_IMPLEMENTATION.md) - Guide détaillé

**Bon courage! 🚀**
